// =============================================
//  JANNATUL FERDUSH ANY — script.js
// =============================================

// ---- Navbar scroll ----
const nav = document.querySelector('nav');
window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > 20);
});

// ---- Hamburger / Overlay menu ----
const burger   = document.querySelector('.hamburger');
const overlay  = document.querySelector('.nav-overlay');

burger.addEventListener('click', () => {
  burger.classList.toggle('open');
  overlay.classList.toggle('open');
  document.body.style.overflow = overlay.classList.contains('open') ? 'hidden' : '';
});

document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    burger.classList.remove('open');
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  });
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    burger.classList.remove('open');
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }
});

// ---- Scroll reveal ----
const revealEls = document.querySelectorAll('.reveal');
const revObs = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      setTimeout(() => entry.target.classList.add('visible'), i * 90);
      revObs.unobserve(entry.target);
    }
  });
}, { threshold: 0.1 });
revealEls.forEach(el => revObs.observe(el));

// ---- Lightbox (gallery page) ----
const lb      = document.querySelector('.lightbox');
const lbImg   = lb ? lb.querySelector('img') : null;
const lbClose = document.querySelector('.lb-close');

document.querySelectorAll('.gallery-item').forEach(item => {
  item.addEventListener('click', () => {
    const src = item.querySelector('img').src;
    lbImg.src = src;
    lb.classList.add('open');
    document.body.style.overflow = 'hidden';
  });
});

if (lbClose) {
  lbClose.addEventListener('click', closeLb);
}
if (lb) {
  lb.addEventListener('click', e => { if (e.target === lb) closeLb(); });
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLb(); });

function closeLb() {
  if (!lb) return;
  lb.classList.remove('open');
  document.body.style.overflow = '';
}

// ---- Contact form ----
const form = document.querySelector('.contact-form');
if (form) {
  form.addEventListener('submit', e => {
    e.preventDefault();
    const btn = form.querySelector('.form-submit');
    btn.textContent = 'Message Sent ✓';
    btn.style.background = '#4CAF50';
    setTimeout(() => {
      btn.textContent = 'Send Message';
      btn.style.background = '';
    }, 3000);
    form.reset();
  });
}

// ---- Mark active nav link ----
const page = window.location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('.nav-links a').forEach(a => {
  if (a.getAttribute('href') === page) a.style.color = 'var(--rose-soft)';
});
